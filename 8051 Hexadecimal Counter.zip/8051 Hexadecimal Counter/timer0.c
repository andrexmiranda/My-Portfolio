#include <SI_EFM8BB3_Register_Enums.h>


static void(*p_call_back)(void)=0;

void init_timer0 (void(*apontador)(void)){				
    TMOD|=2;
    TH0=TL0=-250;
    CKCON0|=2;
    IE =0x82; //ie_ea=1, ie_et0=1
    TCON_TR0=0;
		p_call_back=apontador;
}


void start_timer0(void){  
    TCON_TR0=1;
}


void isr_timer0(void) interrupt 1{
		if(p_call_back) 
			p_call_back();
	
}