#include <SI_EFM8BB3_Register_Enums.h>
#include "keyBoard.h"


char _getkey (void){
	char c=0;
    if(SCON0_RI==1){
        c=SBUF0;
        SCON0_RI=0;
    }
    return c;
}
