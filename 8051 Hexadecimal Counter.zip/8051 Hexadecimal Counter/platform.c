#include <SI_EFM8BB3_Register_Enums.h>
#include "platform.h"



//void init_PCA0(void){
//	PCA0MD = PCA0MD_CPS__SYSCLK_DIV_4;
//	PCA0CPM0 = (PCA0CPM0_PWM__ENABLED | PCA0CPM0_ECOM__ENABLED);	
//	PCA0CPH0 = PCA0CPL0 = 0x80;
//	
//	XBR1 = XBR1_PCA0ME__CEX0;
//	P0SKIP = P0SKIP_B0__SKIPPED;
//	
//	P0MDOUT = P0MDOUT_B1__PUSH_PULL;
//	PCA0CN0 = PCA0CN0_CR__RUN;
//}

	
void init_platform(void){

	WDTCN = 0xDE;
	WDTCN = 0xAD;
	
	SFRPAGE = 0;
	CLKSEL = 0;
	SFRPAGE = 0x10;
	PFE0CN = 0x10;
	SFRPAGE = 0;
	CLKSEL = 0x03;
	CLKSEL = 0x03;
	CLKSEL = 0x03;

	XBR2 = 0x40;
	
}
