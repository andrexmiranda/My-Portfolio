#ifndef TIMER0_MOD
#define TIMER0_MOD


void init_timer0 (void(*apontador)(void));
void start_timer0 (void);

#endif