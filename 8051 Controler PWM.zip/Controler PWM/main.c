#include <SI_EFM8BB3_Register_Enums.h>
#include <stdint.h>
#include <stdio.h>
#include "platform.h"
#include "debounce.h"
#include "timer0.h"
#include "keyBoard.h"
#include "uart0.h"
#include "PCA0.h"


volatile vkey kSet, kLoad;
volatile uint8_t i = 8;
uint8_t index_display = 8;

uint8_t code display7s[]={0xc0,0xcf,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x98,0x88,0x83,0xC6,0xA1,0x86,0x8E};
uint8_t code displayUart[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

typedef enum{ON = 0,OFF} fsm_state_t;
static fsm_state_t state, next_state;

void fsm_init (void){
	state = ON;
	next_state = ON;
}

void fsm_switch_state (void){
	state = next_state;
}

void fsm_encode_state (void){
	bit update;
	char c;
	
	c=_getkey();
	
	switch (state){
		
		case ON:
		
		EIE1 |= EIE1_EPCA0__ENABLED;   //ativa interrup��es da PCA
			
		if(kSet.kold!=kSet.knew || c=='i' || c=='I'){
			kSet.kold=kSet.knew;
			if(!kSet.knew || c=='i' || c=='I'){
				IE_EA = 0;
				i++;
				update = 1;
				IE_EA = 1;
			}
		}
		
		if(kLoad.kold!=kLoad.knew || c=='d' || c=='D'){
			kLoad.kold=kLoad.knew;
			if(!kLoad.knew || c=='d' || c=='D'){
			IE_EA = 0;
			i--;
			update = 1;
			IE_EA = 1;
			}
		}
		
		if (update){
		i = i&0xf;
		P1 = display7s[i];
		printf("%c\n", displayUart[i]);
		update = 0;
	}
	
	if(c=='P'||c=='p')
		next_state=OFF;
	break;
	
		
	case OFF:
	EIE1 |= EIE1_EPCA0__DISABLED;     //desativa interrup��es da PCA
	if(c=='o'||c=='O')
		next_state=ON;
	break;
	
	}
}	
		
		
		
void firstCB(void){
		myCallBack(&kSet);
		myCallBack(&kLoad);
}


void main (void){
		init_platform();
		init_uart0();
	  init_timer0(firstCB);
		init_vkey(&kSet,7,40);
		init_vkey (&kLoad,6,60);
		init_PCA0 ();
			
		fsm_init();
	
    start_timer0();

		P1=display7s[8];
	
    while (1){
			fsm_encode_state();
			fsm_switch_state();
 }
}

	

		
		
