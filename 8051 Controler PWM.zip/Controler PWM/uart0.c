#include <SI_EFM8BB3_Register_Enums.h>
#include <stdint.h>
#include <stdio.h>


void init_uart0(void){
    XBR0=1;
    SCON0= 0x10;         //enable Rx
    CKCON0 |= (1<<CKCON0_T1M__SHIFT);

    TMOD |=0x20;
    TH1=43;
    TL1=43;         //Baudrate 115200 Sysclk 49MHz
    TCON_TR1 = 1;
    SCON0_TI=1;
}