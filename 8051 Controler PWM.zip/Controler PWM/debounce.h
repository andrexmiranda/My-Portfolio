#ifndef __DEBOUNCE_MOD__
#define __DEBOUNCE_MOD__

extern bit kSet_old, kSet_new;

typedef enum {KEY_IDDLE=0, KEY_PRESSED} key_status_t;

struct virtual_key{
	unsigned char counter;
	unsigned char window;
	unsigned char conta1s;
	unsigned char bit_mask;
	key_status_t kold;
	key_status_t knew;
	};

typedef struct virtual_key vkey;
	
void init_vkey (vkey* p_key, unsigned char bit_pos, counter);
void myCallBack(vkey* p_key);
	
	
#endif