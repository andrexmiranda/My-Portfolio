#ifndef __PCA0_MOD__
#define __PCA0_MOD__


#endif

void init_PCA0 (void);
