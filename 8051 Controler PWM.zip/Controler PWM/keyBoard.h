#ifndef __KEYBOARD_MOD__
#define __KEYBOARD_MOD__

char _getkey (void);


#endif