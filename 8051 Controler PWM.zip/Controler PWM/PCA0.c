#include <SI_EFM8BB3_Register_Enums.h>
#include "PCA0.h"

#define ECOMP_BIT 6
#define MAT_BIT 3
#define PWM_BIT 1
#define ECCF_BIT 0

unsigned char code coef[]= {144, 176, 205,227,244, 253, 254, 249, 238, 222, 202, 178, 153, 127, 100, 75, 52, 32, 16, 5, 1, 3, 12, 29, 52, 80, 113};
extern uint8_t i;


void init_PCA0(void){
	PCA0MD = PCA0MD_CPS__T0_OVERFLOW;
	PCA0CPM0 = (PCA0CPM0_PWM__ENABLED | PCA0CPM0_ECOM__ENABLED);
	PCA0CPH0 = coef[0];
	PCA0CPL0 =	coef[0];
	
	
	XBR1 = XBR1_PCA0ME__CEX0;
	P0SKIP = P0SKIP_B0__SKIPPED;
	
	P0MDOUT = P0MDOUT_B1__PUSH_PULL;
	PCA0CN0 = PCA0CN0_CR__RUN;
	
	//Modulo 1 software timer
	
	PCA0CPM1 = (1<<ECOMP_BIT) | (1<<MAT_BIT) | (1<<ECCF_BIT);
	PCA0CPL1 = 0x00;
	PCA0CPH1 = 0x01;
	
	EIE1 |= EIE1_EPCA0__ENABLED;
	
	PCA0CN0_CR = 1;
}


void pca_isr (void) interrupt 11{
	
	PCA0CPH0 = coef[i];

	PCA0CPH1++;
	
	PCA0CN0  &= ~(PCA0CN0_CCF1__SET);
}
	
	
	
	
	
	
	
	
	
	
	
	
	

