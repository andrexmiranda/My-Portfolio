#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#endif

void init_platform(void);


