#include <SI_EFM8BB3_Register_Enums.h>
#include "debounce.h"


void init_vkey (vkey* p_key, unsigned char bit_pos,counter){
    p_key -> window=0xff;
    p_key -> conta1s=8;
    p_key -> bit_mask=1<<bit_pos;
    p_key -> knew = KEY_IDDLE;
    p_key -> kold = KEY_IDDLE;
}


void myCallBack(vkey* p_key){
	
	bit pin;
	
	if(++p_key->counter==0){
		p_key->counter=-40;
	  pin = (P0 & p_key->bit_mask);
	  p_key->conta1s-=(p_key->window>>7);
		p_key->window<<=1;
		p_key->conta1s+=(uint8_t)pin;
		
		p_key->window|=(uint8_t) pin;
		p_key->kold = p_key->knew;
		p_key->knew=((p_key->conta1s-4)>>7);
	}
}
