#ifndef UART0_MOD
#define UART0_MOD

#endif



void init_uart0 (void);